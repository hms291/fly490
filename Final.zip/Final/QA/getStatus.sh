#!/bin/bash

#status either good/bad

read -p "What is the status change? good/bad: " STATUS
echo "${STATUS}"
