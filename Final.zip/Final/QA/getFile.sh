#!/bin/bash

#cd /home/hassan/Deploy/QA/Files
cd ~/QA/Files
#Get the package name that you are testing.

FILE=`ls`
echo "${FILE}"

