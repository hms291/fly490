#!/bin/bash

cd ~/QA/Files/
#Get the package name that you are hosting at the moment.

FILE=`ls`
echo "${FILE}"

