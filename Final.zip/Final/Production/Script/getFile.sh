#!/bin/bash

#cd /home/franny/deploy/Production/Pakages
cd ~/Deploy/Production/Files/
#Get the package name that you are hosting at the moment.

FILE=`ls`
echo "${FILE}"

