read -p "Which version you want send: " file
echo "$file"

