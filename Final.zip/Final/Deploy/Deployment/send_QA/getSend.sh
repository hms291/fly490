#!/bin/bash
#Ask Deploy if they want to send to QA : FE or BE
read -p "Which QA machine are you sending to? FE or BE: " MACH
echo "$MACH"
