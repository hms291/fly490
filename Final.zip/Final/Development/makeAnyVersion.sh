

read -p "Which Version you want to send? : " nextV
echo "$nextV"
